<?php
/**
 * Settings Class
 *
 * Handles WordPress Settings API integration
 *
 * @package CWP_Chat_Bubbles
 * @since 1.0.0
 */

// Prevent direct access
defined('ABSPATH') or exit;

/**
 * CWP Chat Bubbles Settings Class
 *
 * @since 1.0.0
 */
class CWP_Chat_Bubbles_Settings {

    /**
     * Instance of this class
     *
     * @var CWP_Chat_Bubbles_Settings
     * @since 1.0.0
     */
    private static $instance = null;

    /**
     * Settings option name
     *
     * @var string
     * @since 1.0.0
     */
    private $option_name = 'cwp_chat_bubbles_options';

    /**
     * Get instance
     *
     * @return CWP_Chat_Bubbles_Settings
     * @since 1.0.0
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     *
     * @since 1.0.0
     */
    private function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Register plugin settings
     *
     * @since 1.0.0
     */
    public function register_settings() {
        register_setting(
            'cwp_chat_bubbles_settings',
            $this->option_name,
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_options'),
                'default' => $this->get_default_options()
            )
        );
    }

    /**
     * Get default options
     *
     * @return array Default options
     * @since 1.0.0
     */
    public function get_default_options() {
        return array(
            // General settings
            'enabled' => true,
            'auto_load' => true,
            'position' => 'bottom-right',
            'custom_main_icon' => 0,            // Custom main icon attachment ID, 0 = use default
            
            // Display settings
            'main_button_color' => '#52BA00',
            'animation_enabled' => true,
            'show_labels' => true,              // Global setting for all items
            'offset_x' => 0,                    // Horizontal offset in pixels (-200 to 200)
            'offset_y' => 0,                    // Vertical offset in pixels (-200 to 200)
            
            // Advanced settings
            'custom_css' => '',
            'load_on_mobile' => true,
            'exclude_pages' => array()
        );
    }

    /**
     * Sanitize and validate options
     *
     * @param array $options Raw options from form
     * @return array Sanitized options
     * @since 1.0.0
     */
    public function sanitize_options($options) {
        $sanitized = array();

        // Sanitize general settings
        // Note: For checkboxes, if not present in POST data, it means unchecked
        $sanitized['enabled'] = isset($options['enabled']) ? (bool) $options['enabled'] : false;
        $sanitized['auto_load'] = isset($options['auto_load']) ? (bool) $options['auto_load'] : false;
        $sanitized['position'] = isset($options['position']) ? sanitize_text_field($options['position']) : 'bottom-right';
        
        // Sanitize custom main icon
        $sanitized['custom_main_icon'] = isset($options['custom_main_icon']) ? absint($options['custom_main_icon']) : 0;
        // Validate that attachment exists if not 0
        if ($sanitized['custom_main_icon'] > 0 && !wp_get_attachment_url($sanitized['custom_main_icon'])) {
            $sanitized['custom_main_icon'] = 0; // Reset to default if attachment doesn't exist
        }

        // Validate position
        $valid_positions = array('bottom-right', 'bottom-left', 'top-right', 'top-left');
        if (!in_array($sanitized['position'], $valid_positions)) {
            $sanitized['position'] = 'bottom-right';
        }

        // Note: Platform-specific settings are now handled by Items Manager custom table

        // Sanitize display settings
        $sanitized['main_button_color'] = isset($options['main_button_color'])
            ? sanitize_hex_color($options['main_button_color'])
            : '#52BA00';
            
        $sanitized['animation_enabled'] = isset($options['animation_enabled'])
            ? (bool) $options['animation_enabled']
            : false;
            
        $sanitized['show_labels'] = isset($options['show_labels'])
            ? (bool) $options['show_labels']
            : false;

        // Sanitize offset settings
        $sanitized['offset_x'] = isset($options['offset_x']) 
            ? max(-200, min(200, (int) $options['offset_x'])) 
            : 0;
            
        $sanitized['offset_y'] = isset($options['offset_y']) 
            ? max(-200, min(200, (int) $options['offset_y'])) 
            : 0;

        // Sanitize advanced settings - Enhanced CSS validation
        $sanitized['custom_css'] = '';
        if (isset($options['custom_css']) && !empty($options['custom_css'])) {
            $css = wp_strip_all_tags($options['custom_css']);
            
            // Additional CSS security - remove potentially dangerous functions
            $dangerous_patterns = array(
                '/javascript\s*:/i',
                '/expression\s*\(/i',
                '/url\s*\(\s*["\']?\s*javascript:/i',
                '/url\s*\(\s*["\']?\s*data:/i',
                '/import\s*["\']?/i',
                '/@import/i',
                '/behavior\s*:/i',
                '/binding\s*:/i',
                '/mozbinding\s*:/i'
            );
            
            foreach ($dangerous_patterns as $pattern) {
                $css = preg_replace($pattern, '', $css);
            }
            
            // Limit CSS length to prevent abuse
            if (strlen($css) > 5000) {
                $css = substr($css, 0, 5000);
            }
            
            $sanitized['custom_css'] = $css;
        }
            
        $sanitized['load_on_mobile'] = isset($options['load_on_mobile'])
            ? (bool) $options['load_on_mobile']
            : false;

        // Sanitize exclude pages
        $sanitized['exclude_pages'] = array();
        if (isset($options['exclude_pages']) && is_array($options['exclude_pages'])) {
            foreach ($options['exclude_pages'] as $page_id) {
                $sanitized['exclude_pages'][] = absint($page_id);
            }
        }

        return $sanitized;
    }

    /**
     * Get all plugin options
     *
     * @return array Plugin options
     * @since 1.0.0
     */
    public function get_options() {
        return get_option($this->option_name, $this->get_default_options());
    }

    /**
     * Update plugin options
     *
     * @param array $options New options
     * @return bool Always returns true unless there's an error
     * @since 1.0.0
     */
    public function update_options($options) {
        $sanitized_options = $this->sanitize_options($options);
        
        // update_option returns false if the value hasn't changed, not if there's an error
        // We always want to clear caches and return success for UX purposes
        update_option($this->option_name, $sanitized_options);
        
        // Always clear frontend caches when settings are processed
        $this->clear_frontend_caches();
        
        // Return true to indicate successful processing
        return true;
    }

    /**
     * Clear frontend caches when settings change
     *
     * @since 1.0.0
     */
    private function clear_frontend_caches() {
        // Clear specific cache keys first
        $cache_keys_to_clear = array(
            'cwp_chat_bubbles_data_version',
            'cwp_chat_bubbles_frontend_data'
        );
        
        foreach ($cache_keys_to_clear as $key) {
            wp_cache_delete($key, 'cwp_chat_bubbles');
        }
        
        // Try to clear cache group if function exists (not all cache systems support this)
        if (function_exists('wp_cache_delete_group')) {
            wp_cache_delete_group('cwp_chat_bubbles');
        }
    }

    /**
     * Get specific option
     *
     * @param string $key Option key (supports dot notation for nested values)
     * @param mixed $default Default value
     * @return mixed Option value
     * @since 1.0.0
     */
    public function get_option($key, $default = null) {
        $options = $this->get_options();
        
        // Support dot notation for nested values
        if (strpos($key, '.') !== false) {
            $keys = explode('.', $key);
            $value = $options;
            
            foreach ($keys as $k) {
                if (!isset($value[$k])) {
                    return $default;
                }
                $value = $value[$k];
            }
            
            return $value;
        }
        
        return isset($options[$key]) ? $options[$key] : $default;
    }

    /**
     * Check if plugin is enabled
     *
     * @return bool Whether plugin is enabled
     * @since 1.0.0
     */
    public function is_enabled() {
        return (bool) $this->get_option('enabled', true);
    }

    /**
     * Check if auto-loading is enabled
     *
     * @return bool Whether auto-loading is enabled
     * @since 1.0.0
     */
    public function is_auto_load_enabled() {
        return (bool) $this->get_option('auto_load', true);
    }

    /**
     * Check if labels should be shown
     *
     * @return bool Whether labels should be shown for all items
     * @since 1.0.0
     */
    public function should_show_labels() {
        return (bool) $this->get_option('show_labels', true);
    }

    /**
     * Get main icon URL
     *
     * @return string Main icon URL (custom or default)
     * @since 1.0.2
     */
    public function get_main_icon_url() {
        $custom_icon_id = $this->get_option('custom_main_icon', 0);
        
        if ($custom_icon_id > 0) {
            $custom_icon_url = wp_get_attachment_url($custom_icon_id);
            if ($custom_icon_url) {
                return $custom_icon_url;
            }
        }
        
        return CWP_CHAT_BUBBLES_PLUGIN_URL . 'assets/images/support.svg';
    }
} 