<?php
/**
 * CWP Chat Bubbles Uninstall
 *
 * @package CWP_Chat_Bubbles
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('cwp_chat_bubbles_settings');
delete_option('cwp_chat_bubbles_version');

// Clear any cached data
wp_cache_flush();
